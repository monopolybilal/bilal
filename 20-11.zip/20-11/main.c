#include "plateau.h"


int main(){
    t_plateau terrain;
    initialiserPlateau(&terrain);
    Menu(terrain);



}
